package hbtec.com.hospital;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.app.ProgressDialog;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ProgressDialog progressDialog;
    ProgressBar progress;
    WebView hospital;
    String Address;
    SwipeRefreshLayout swipe;
    ImageView imageView;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView)findViewById(R.id.imageView);
        swipe = (SwipeRefreshLayout) findViewById(R.id.swipe);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                WebAction();
            }
        });


        WebAction();
    }
    public void WebAction(){

        hospital = (WebView) findViewById(R.id.hospital);
        //progress = (ProgressBar) findViewById(R.id.progressBar);
        //progress.setVisibility(View.VISIBLE);
       Address = "https://henryoseah.pythonanywhere.com";
        hospital.getSettings().setLoadsImagesAutomatically(true);
        hospital.getSettings().setJavaScriptEnabled(true);
      //  hospital.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		//hospital.setScrollBarStyle(false);
		hospital.setVerticalScrollBarEnabled(false);
		hospital.setHorizontalScrollBarEnabled(false);
        swipe.setRefreshing(true);
        hospital.loadUrl(Address);
        hospital.setWebViewClient(new Bro());




    }


    private class Bro extends WebViewClient {


                
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
            hospital.setVisibility(View.GONE);
            imageView.setVisibility(View.VISIBLE);




        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon){
            super.onPageStarted(view,url,favicon);

        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url){



            view.loadUrl(url);


            return true;
        }
        public void onLoadResource(WebView view,String url){
        if (progressDialog == null){
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.show();
            hospital.setVisibility(View.VISIBLE);
            imageView.setVisibility(View.GONE);

        
        }
        }
        public void onPageFinished(WebView view, String url){
			try{
			if (progressDialog.isShowing()){
                progressDialog.dismiss();
                progressDialog = null;


			}
			}catch(Exception exception){
			exception.printStackTrace();
			}
            super.onPageFinished(view, url);
            swipe.setRefreshing(false);
        }


    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if((keyCode == KeyEvent.KEYCODE_BACK) && hospital.canGoBack()){
            hospital.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}


